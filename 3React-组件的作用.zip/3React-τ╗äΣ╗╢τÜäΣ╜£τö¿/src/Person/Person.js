import React from 'react';
const person = ( ) => {
  return <p>大家好,我是米斯特吴!</p>
     
}

export default person;