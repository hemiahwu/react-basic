import React from 'react';
const person = ( props ) => {
  return (
    <div>
      <p onClick={props.myclick}>大家好,我是{props.name}! 我已经拥有{props.count}个作品</p>
      <p>{props.children}</p>
    </div>
  )
}

export default person;